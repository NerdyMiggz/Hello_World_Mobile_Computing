package com.helloworld.rosa_hello_world;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("MainActivity", "Hello World");
    }

    /*public static Toast makeText(Context context, int resId, int duration) throws Resources.NotFoundException{
        context = getApplicationContext();
        CharSequence text = "hello toast!";
        duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText();
        toast.show();

        return Toast;
    }*/

    public void toastMsg(String msg){
        Toast toast = Toast.makeText(this, msg, Toast.LENGTH_LONG);
        toast.show();
    }

    public void displayToastMsg(View v){
        toastMsg("Hello Toast!");
    }

    public static void main(String[] args) {
        //Toast.makeText(getActivity(),)
        System.out.println("Hello World! How are ya?");
    }
}
